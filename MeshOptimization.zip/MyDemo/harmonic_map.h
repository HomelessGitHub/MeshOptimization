#pragma once
#include "MyMesh.h"
#include "../MeshLib/core/Structure.h"
#include "../MeshLib/core/Mesh/iterators.h"
#include <Eigen/Sparse>

using namespace MeshLib;

class harmornicMap
{
public:
	harmornicMap(CMyMesh* pMesh) : input_mesh(pMesh), boundary(input_mesh)
	{
		int vid = 0;
		int vfid = 0;
		for (CMyMesh::MeshVertexIterator viter(input_mesh); !viter.end(); ++viter)
		{
			CMyVertex * pV = *viter;
			if (pV->boundary())
			{
				pV->idx() = vfid++;
			}
			else
			{
				pV->idx() = vid++;
			}
		}
		input_vertices = vid;
		input_bVertices = vfid;
		CStructure<CMyMesh, CMyVertex, CMyEdge, CMyFace, CMyHalfEdge> LY(input_mesh);
		LY._embedding_2_metric();
		LY._metric_2_angle();
		LY._angle_2_Laplace();
	}
	~harmornicMap() {}

	void harmonic(double threshould = 5e-4)
	{
		setBoundary();
		for (CMyMesh::MeshVertexIterator viter(input_mesh); !viter.end(); ++viter)
		{
			CMyVertex * pV = *viter;
			if (pV->boundary()) continue;
			pV->huv() = CPoint(0, 0, 0);
		}
		int i = 0;
		while (true)
		{
			std::cout << "iteration: " << ++i << "\n";
			double error = -1e+10;
			for (CMyMesh::MeshVertexIterator viter(input_mesh); !viter.end(); ++viter)
			{
				CMyVertex * pV = *viter;
				if (pV->boundary()) continue;

				double  tmp = 0;
				CPoint suv(0, 0, 0);
				for (CMyMesh::VertexVertexIterator vviter(pV); !vviter.end(); vviter++)
				{
					CMyVertex * pW = *vviter;
					CMyEdge   * pE = input_mesh->vertexEdge(pV, pW);
					double w = pE->weight();
					tmp += w;
					suv = suv + pW->huv() * w;
				}
				suv /= tmp;
				double verror = (pV->huv() - suv).norm();
				error = (verror > error) ? verror : error;
				pV->huv() = suv;
			}
			if (error < threshould) break;
		}
	}

	  void Laplas_map() 
	  {
	      setBoundary();

	      std::vector<Eigen::Triplet<double> > A_c;
	      std::vector<Eigen::Triplet<double> > B_c;

	      
	      for( CMyMesh::MeshVertexIterator viter( input_mesh ); !viter.end(); ++ viter )
	      {
	          CMyVertex * pV = *viter;
	          if( pV->boundary() ) continue;
	          int vid = pV->idx();

	          double tmp = 0;
	          for( CMyMesh::VertexVertexIterator witer( pV ); !witer.end(); ++ witer )
	          {
	              CMyVertex * pW = *witer;
	              CMyEdge * e = input_mesh->vertexEdge( pV, pW );
			int wid = pW->idx();
	              double w = e->weight();
	              if( pW->boundary())
	              {
	                  Eigen::Triplet<double> e(vid,wid,w);
	                  B_c.push_back(e);
	              }
	              else
	              {
	                  A_c.push_back( Eigen::Triplet<double>(vid,wid, -w) );
	              }
	              tmp += w;
	          }
	          A_c.push_back( Eigen::Triplet<double>(vid,vid, tmp ) );
	      }
	      Eigen::SparseMatrix<double> M_1( input_vertices, input_vertices );
	      M_1.setZero();
	      Eigen::SparseMatrix<double> M_2( input_vertices, input_bVertices );
	      M_2.setZero();
	      M_1.setFromTriplets(A_c.begin(), A_c.end());
	      M_2.setFromTriplets(B_c.begin(), B_c.end());
	Eigen::ConjugateGradient<Eigen::SparseMatrix<double>> solver;
	      if( solver.info() != Eigen::Success )
	      {
	          std::cerr << "Something is wrong" << std::endl;
	      }
	      for( int k = 0; k < 2; k ++ )
	      {
	          Eigen::VectorXd b(input_bVertices);
	          for( CMyMesh::MeshVertexIterator viter( input_mesh ); !viter.end(); ++ viter )
	          {
	              CMyVertex * pV = *viter;
	              if( !pV->boundary() ) continue;
	              int id = pV->idx();
	              b(id) = pV->huv()[k];
	          }
	          Eigen::VectorXd c(input_vertices);
	          c = M_2 * b;
		Eigen::VectorXd x = solver.compute(M_1).solve(c);
	          if( solver.info() != Eigen::Success )
	          {
	              std::cerr << "stupid !" << std::endl;
	          }

	          //set the images of the harmonic map to interior vertices
	          for( CMyMesh::MeshVertexIterator viter( input_mesh ); !viter.end(); ++ viter )
	          {
	              CMyVertex * pV = *viter;
	              if( pV->boundary() ) continue;
	              int id = pV->idx();
	              pV->huv()[k] = x(id);
	               pV->point()[k] = x(id);   //add ----------------------------
	          }

	      }

	      for( CMyMesh::MeshVertexIterator viter( input_mesh ); !viter.end(); ++ viter )
	      {
	          CMyVertex * pV = *viter;
	          if( pV->boundary() ) continue;
	          pV->huv()[2] = 0;
	          // pV->point()[k] = x(id);   //add ----------------------------
	      }
	      std::cout << "Over\n";
	  }

protected:
	CMyMesh* input_mesh;
	CMyMesh::CBoundary boundary;
	int input_vertices;
	int input_bVertices;

    void setBoundary()  
    {
        std::vector<CMyMesh::CLoop*> & lps =  boundary.loops();
        CMyMesh::CLoop * lp = lps[0];
        std::list<CMyHalfEdge*> & hes = lp->halfedges();
        double sum = 0;
        for( std::list<CMyHalfEdge*>::iterator iter = hes.begin(); iter != hes.end(); iter ++ )
        {
            CMyHalfEdge * ph = *iter;
            CMyEdge * pE = input_mesh->halfedgeEdge( ph );
            sum += pE->length();
        }

        double l = 0;
        for( std::list<CMyHalfEdge*>::iterator iter = hes.begin(); iter != hes.end(); iter ++ )
        {
            CMyHalfEdge * ph = *iter;
            CMyEdge * pE = input_mesh->halfedgeEdge( ph );
            l += pE->length();
            double ang = l/sum * 2.0 * PI;
            CMyVertex * pV = input_mesh->halfedgeTarget( ph );
            pV->huv()= CPoint( (cos(ang)+1.0)/2.0, (sin(ang)+1.0)/2.0, 0 );
        }
    }
};

void h_main(CMyMesh & mesh)
{
    harmornicMap mapper(&mesh);
    //mapper.Laplas_map();
	mapper.harmonic();
}