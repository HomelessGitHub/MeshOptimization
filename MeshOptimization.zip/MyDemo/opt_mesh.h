#pragma once
#include "harmonic_map.h"


namespace meshOptimation {

    using namespace MeshLib;

    double len_halfedge(CHalfEdge * he)
    {
        CPoint p1 = he->vertex()->point(),
               p2 = he->he_prev()->vertex()->point();
        return (p1[0] - p2[0]) * (p1[0] - p2[0]) + (p1[1] - p2[1]) * (p1[1] - p2[1]) +(p1[2] - p2[2]) * (p1[2] - p2[2]);
    }


	CPoint baryCenter(CFace * face)
	{
		CPoint  v0 = ((CMyVertex*)face->halfedge()->vertex())->huv(),
			v1 = ((CMyVertex*)face->halfedge()->he_next()->vertex())->huv(),
			v2 = ((CMyVertex*)face->halfedge()->he_prev()->vertex())->huv();
		CPoint  va = (v0 + v1) / 2.0,
			vb = (v0 + v2) / 2.0;
		double ka = (v0[0] - v1[0]) / (v1[1] - v0[1]),
			kb = (v0[0] - v2[0]) / (v2[1] - v0[1]);
		double ba = va[1] - ka * va[0],
			bb = vb[1] - kb * vb[0];
		double x = (bb - ba) / (ka - kb),
			y = ka * (bb - ba) / (ka - kb) + ba;
		return CPoint(x, y, 0.0);
	}

    double mini_jiao(CFace * face) 
    {
        CHalfEdge *h0 = face->halfedge(),
                  *h1 = h0->he_next(),
                  *h2 = h0->he_prev();
        CPoint e_0_a = ((CMyVertex*)h1->vertex())->huv() - ((CMyVertex*)h0->vertex())->huv(),
               e_0_b = ((CMyVertex*)h2->vertex())->huv() - ((CMyVertex*)h0->vertex())->huv(),
               e_1_a = ((CMyVertex*)h0->vertex())->huv() - ((CMyVertex*)h1->vertex())->huv(),
               e_1_b = ((CMyVertex*)h2->vertex())->huv() - ((CMyVertex*)h1->vertex())->huv(),
               e_2_a = ((CMyVertex*)h0->vertex())->huv() - ((CMyVertex*)h2->vertex())->huv(),
               e_2_b = ((CMyVertex*)h1->vertex())->huv() - ((CMyVertex*)h2->vertex())->huv();
        double ang_0 = acos(e_0_a * e_0_b / mod(e_0_a) / mod(e_0_b)),
               ang_1 = acos(e_1_a * e_1_b / mod(e_1_a) / mod(e_1_b)),
               ang_2 = acos(e_2_a * e_2_b / mod(e_2_a) / mod(e_2_b));
        return std::min(ang_0, std::min(ang_1, ang_2));
    }

    void opt_insert(CMyMesh& mesh, CFace * f) 
    {

        CPoint p = baryCenter(f);   

        CFace* face = LocatePoint(mesh, p);
        if (face != NULL) {
            CHalfEdge *h0 = face->halfedge(),
                      *h1 = h0->he_next(),
                      *h2 = h0->he_prev();
            CPoint p_org_avg =  (h0->vertex()->point() + 
                                 h1->vertex()->point() + 
                                 h2->vertex()->point()) / 3.0;
            CPoint n_avg = (h0->vertex()->normal() + 
                                h1->vertex()->normal() + 
                                h2->vertex()->normal()) / 3.0;
            CVertex* _v_ = faceSplit(mesh, face, p, p_org_avg, n_avg);

            assert(h0->he_next()->vertex() == h1->he_next()->vertex() 
                   && h0->he_next()->vertex() == h2->he_next()->vertex());
            CVertex* v = h0->he_next()->vertex();
            legalizeEdge(mesh, v, h0->edge());
            legalizeEdge(mesh, v, h1->edge());
            legalizeEdge(mesh, v, h2->edge());    
        }
    } 

    void opt_split(CMyMesh & mesh, CFace * theface, double length_ref)
    {
        CHalfEdge *h0 = theface->halfedge(),
                *h1 = h0->he_next(),
                *h2 = h0->he_prev();
        double l0 = len_halfedge(h0),
                l1 = len_halfedge(h1),
                l2 = len_halfedge(h2);
        if (std::min(l2, std::min(l0, l1)) > length_ref / 2) {
            if (l0 > l1 && l0 > l2) {
                myEdgeSplit(mesh, h0->edge());
            }
            if (l1 > l0 && l1 > l2) {
                myEdgeSplit(mesh, h1->edge());
            }
            if (l2 > l1 && l2 > l0) {
                myEdgeSplit(mesh, h2->edge());
            }
        }
    }

    void optMesh(CMyMesh& mesh)  
    {
        std::list<CMyFace*>::iterator it = (mesh.faces()).begin();
        CFace * pF = *it;
        double min_length = ( len_halfedge(pF->halfedge()) + 
                            len_halfedge(pF->halfedge()->he_prev()) +
                            len_halfedge(pF->halfedge()->he_next()) ) / 3.0;
        int i = 0, j = 0;
        for (; i < mesh.faces().size(); ++i)
        {
            std::cout << "iterations: " << "		" << i << "\n";
            std::list<CMyFace*>::iterator it = (mesh.faces()).begin(); 
            std::advance(it, i); 
            CFace * pF = *it;
            if (mini_jiao(pF) < 0.6) {    //30
                opt_insert(mesh, pF);
            }
        }
        for (; j < mesh.faces().size(); ++j)
        {
            std::cout << "iterations: " << "		" << i + j << "\n";
            std::list<CMyFace*>::iterator it = (mesh.faces()).begin(); 
            std::advance(it, j); 
            CFace * pF = *it;
            if (mini_jiao(pF) < 0.6) {    //30
                opt_split(mesh, pF, min_length);
            }
        }
    }

}

